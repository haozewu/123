<?php
/**
 * @author ciabeta
 */
class AddBacktop{
    function __construct() {
        include( 'structure/backtop.php' );
    }
}
?>