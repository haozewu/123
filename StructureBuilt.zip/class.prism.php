<?php
/**
 * @author ciabeta
 */
class Prism{
    function __construct() {
        echo '<link rel="stylesheet" href="https://web-share.bj.bcebos.com/css/prism.css" />
	<script src="https://web-share.bj.bcebos.com/js/prism.js" type="text/javascript"></script>
	';
    }
}
?>